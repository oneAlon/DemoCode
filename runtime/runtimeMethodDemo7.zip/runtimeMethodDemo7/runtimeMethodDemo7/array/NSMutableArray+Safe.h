//
//  NSMutableArray+Safe.h
//  runtimeMethodDemo7
//
//  Created by xygj on 2018/7/19.
//  Copyright © 2018年 xygj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (Safe)

@end
